library(testthat)
library(associationsubgraphs)

test_check("associationsubgraphs")
